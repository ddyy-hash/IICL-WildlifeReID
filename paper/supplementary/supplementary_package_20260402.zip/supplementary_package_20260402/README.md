# RIIC-ReID ACM MM 2026 Supplementary Package

This directory is the anonymous supplementary companion for the RIIC-ReID submission. It is organized to let a reviewer move directly from a claim in the main paper to the exact local artifact that supports it.

## Directory map

- `paper/`
  - Anonymous main-paper PDF, LaTeX source, and BibTeX snapshot used for the current submission state.
- `supplementary/`
  - Standalone supplementary LaTeX source and compiled PDF.
- `code/`
  - Minimal paper-facing code subset for model construction, evaluation, ablation generation, and representative tests.
- `config/experiments/`
  - Exact configuration snapshots for the paper-facing experiments:
    - `main_atrw/`
    - `backbone_robustness/`
    - `cross_species_fixedqg/`
    - `perceptual_baselines/`
- `evidence/`
  - Compact CSV/Markdown/JSON summaries that back the supplementary tables and protocol clarifications.

## Fast entry points

- Claim-to-artifact map: `evidence/claim_to_artifact_map.md`
- Baseline clarification: `evidence/baseline_snapshot_clarification.md`
- ATRW main ablation: `evidence/atrw_main_ablation_final.csv`
- ATRW backbone robustness: `evidence/atrw_backbone_robustness.csv`
- Cross-species fixed query/gallery results: `evidence/cross_species_fixedqg_results.csv`
- Perceptual baseline results: `evidence/perceptual_baseline_results.csv`
- Representative case evidence:
  - `evidence/claim_case_summary.csv`
  - `evidence/trust_case_summary.csv`
- Additional reviewer-facing support:
  - `evidence/atrw_ckpt_stability_5_summary.csv`
  - `evidence/atrw_ckpt_stability_5_summary.md`
  - `evidence/candidate_case_bank_summary.csv`
  - `evidence/candidate_case_bank_summary.md`
  - `evidence/trust_case_bank_summary.csv`
  - `evidence/trust_case_bank_summary.md`
  - `evidence/geometry_case_summary.md`
- ATRW protocol clarification: `evidence/atrw_protocol_comparison.md`
- Efficiency notes:
  - `evidence/atrw_efficiency_batch1_riic.md`
  - `evidence/stripehead_runtime_note.md`
  - `evidence/main_ablation_complexity_remote_20260402.md`

## How this package matches the paper

- The main paper tables are backed by local CSV summaries in `evidence/`.
- The exact paper-facing configuration snapshots live in `config/experiments/`.
- The scripts under `code/tools/` now default to these bundled configuration snapshots instead of external workspace-only paths.
- The supplementary PDF in `supplementary/` explains the package at paper level; this `README.md` is the reviewer-facing navigation layer.
- The updated supplementary PDF now also contains full derivations of the three main-paper propositions, plus additional stability and multi-case mechanism evidence.

## Reproduction conventions

- Bundled configuration snapshots are package-root relative.
- Generated runtime outputs are written under `artifacts/generated/` when using the helper scripts.
- Raw datasets, training checkpoints, and large caches are intentionally not bundled.
- If a reviewer wants to dry-run the packaged scripts, the most direct commands are:

```bash
python code/tools/run_atrw_main_ablation.py --data_dir <atrw-train-dir> --data_root <atrw-root> --dry_run
python code/tools/run_cross_species_paper_ablation.py --dry_run
python code/tools/run_perceptual_baseline_ablation.py --dry_run --skip_preprocess
```

## Package scope

This package keeps only the artifacts needed to understand, audit, and retrace the paper-facing results. It excludes:

- raw datasets
- large checkpoints
- exploratory branches not used by the current anonymous paper
- machine-specific absolute paths and reviewer-irrelevant environment details
