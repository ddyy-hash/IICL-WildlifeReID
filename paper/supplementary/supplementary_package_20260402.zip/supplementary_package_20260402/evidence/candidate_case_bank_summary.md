# Candidate Case Bank Summary

This file summarizes 25 candidate ATRW queries used to verify that the qualitative claims are not driven by a single cherry-picked example.

## Aggregate Counts

- Candidate queries analyzed: `25`
- Queries where `AP(RIIC) >= AP(raw baseline)`: `15 / 25`
- Queries where `AP(RetinexNet) < AP(raw baseline)`: `25 / 25`
- Queries where `AP(Zero-DCE++) < AP(raw baseline)`: `25 / 25`

## Mean AP Deltas Across the Bank

- Mean `AP(RIIC) - AP(raw baseline)`: `+0.0054`
- Mean `AP(raw baseline) - AP(RetinexNet)`: `+0.3061`
- Mean `AP(raw baseline) - AP(Zero-DCE++)`: `+0.2858`

## Interpretation

- The representative qualitative example matches a broader pattern: generic perceptual enhancement is consistently weaker than the raw baseline on this candidate bank.
- RIIC is not uniformly better than the raw baseline on every individual query, but it is usually non-degrading and clearly less destructive than the perceptual alternatives.
