# Trust Case Bank Summary

This file summarizes the compact trust-diagnostic bank extracted from 25 ATRW candidate queries.

## Range Summary Across the Bank

- Query luminance: `0.1436` to `0.5430`
- Rollback mean: `0.5383` to `0.5570`
- Identity-protection mean: `0.0559` to `0.2415`
- Correction-gap mean: `0.0132` to `0.0496`
- Color-risk mean: `0.000007` to `0.070291`
- Trust score: `0.7147` to `0.8830`

## Mean Summary Across the Bank

- Mean luminance: `0.4091`
- Mean rollback mean: `0.5497`
- Mean identity-protection mean: `0.1148`
- Mean correction-gap mean: `0.0374`
- Mean color-risk mean: `0.0054`
- Mean trust score: `0.8231`

## Interpretation

- Rollback remains conservative and tightly bounded across the bank instead of collapsing toward either zero correction or full replacement.
- Identity protection and correction gap vary more widely, which is consistent with case-dependent trust modulation.
- Color risk is near zero for most cases and becomes appreciable only in a small subset, which is where trust control should matter most.
