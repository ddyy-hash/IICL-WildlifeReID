# Claim-to-Artifact Map

This file provides the quickest reviewer-facing bridge between the anonymous paper and the bundled artifacts.

| Main paper claim | Main paper anchor | Local evidence files | Local config snapshots | Local code entry points |
|---|---|---|---|---|
| RIIC-ReID improves the ATRW main metric from 56.69 to 58.11 mmAP | Abstract, Sec. 5.2, main ablation table | `evidence/atrw_main_ablation_final.csv` | `config/experiments/main_atrw/*.yaml` | `code/tools/run_atrw_main_ablation.py` |
| Gains remain visible across OSNet-AIN, OSNet, and ResNet-50 | Sec. 5.3, backbone robustness table | `evidence/atrw_backbone_robustness.csv` | `config/experiments/backbone_robustness/*.yaml` | `code/tools/run_atrw_main_ablation.py` |
| The same ordering remains visible on GZGC Zebra and StripeSpotter fixed-query/gallery splits | Sec. 5.4, cross-species table | `evidence/cross_species_fixedqg_results.csv` | `config/experiments/cross_species_fixedqg/*.yaml` | `code/tools/run_cross_species_paper_ablation.py` |
| Generic perceptual enhancement is weaker or less consistent than the full model | Sec. 5.5, perceptual baseline table | `evidence/perceptual_baseline_results.csv` | `config/experiments/perceptual_baselines/*.yaml` | `code/tools/run_perceptual_baseline_ablation.py` |
| ATRW headline numbers are reported under an official-like open-set protocol and should not be mixed with custom fixed-query/gallery or closed-set settings | Sec. 5.1, protocol discussion | `evidence/atrw_protocol_comparison.md`, `evidence/atrw_protocol_comparison.csv` | n/a | `code/tools/eval_atrw_openset.py`, `code/tools/eval_atrw_closedset.py`, `code/tools/prepare_atrw_official.py`, `code/tools/create_openset_split.py` |
| Runtime and complexity evidence are supplementary diagnostics, not substitutes for the main retrieval metrics | Supplementary only | `evidence/atrw_efficiency_batch1_riic.md`, `evidence/stripehead_runtime_note.md`, `evidence/main_ablation_complexity_remote_20260402.md`, `evidence/main_ablation_complexity_remote_20260402.json` | `config/experiments/main_atrw/*.yaml` | profiling path documented in the evidence files |
| The exact no-illumination control shipped in the package is a simplified pure-ReID baseline snapshot and should be audited through the literal YAML rather than a prose approximation | Supplementary only | `evidence/baseline_snapshot_clarification.md` | `config/experiments/main_atrw/plain_baseline_exact.yaml` | `code/tools/run_atrw_main_ablation.py` |
| Representative retrieval and trust-mechanism evidence are available beyond the aggregate tables | Supplementary only | `evidence/claim_case_summary.csv`, `evidence/trust_case_summary.csv`, `evidence/cross_species_openset_protocol_difficulty.csv` | package-local figure assets in `supplementary/*.png` | n/a |
| Reliability wording in the interpretation is further backed by a compact checkpoint-stability diagnostic | Supplementary only | `evidence/atrw_ckpt_stability_5_summary.csv`, `evidence/atrw_ckpt_stability_5_summary.md` | n/a | n/a |
| The qualitative and trust-control claims are not based on a single cherry-picked example | Supplementary only | `evidence/candidate_case_bank_summary.csv`, `evidence/candidate_case_bank_summary.md`, `evidence/trust_case_bank_summary.csv`, `evidence/trust_case_bank_summary.md`, `evidence/geometry_case_summary.md` | package-local figure assets in `supplementary/*.png` | n/a |
| The main paper's proposition sketches are expanded into full derivations in the supplementary manuscript | Sec. 3, Propositions 1-3 | `supplementary/acmmm_mm2026_supplementary.tex` | n/a | n/a |

## Source-of-Record Convention

- For paper-facing numbers, the local CSV files under `evidence/` are the primary source of record inside this package.
- For implementation details, the exact YAML snapshots under `config/experiments/` are the source of record.
- The scripts under `code/tools/` default to these bundled configuration snapshots instead of external workspace-only config paths.
