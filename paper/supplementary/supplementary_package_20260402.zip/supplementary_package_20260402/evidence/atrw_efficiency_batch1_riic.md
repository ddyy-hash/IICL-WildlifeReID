# ATRW Efficiency Benchmark (Batch Size 1, 256 x 384)

This table reports package-local batch-1 inference diagnostics for the main ATRW pipeline variants.

| Pipeline | Params (M) | Latency (ms) | FPS | Resident GPU Mem (MB) | Peak GPU Mem (MB) |
|---|---:|---:|---:|---:|---:|
| Matched ReID baseline | 2.28 | 5.10 | 196.03 | 18.11 | 86.61 |
| RIIC front-end only | 0.10 | 10.52 | 95.06 | 38.55 | 290.93 |
| Full RIIC-ReID | 4.57 | 27.26 | 36.68 | 38.55 | 290.18 |
