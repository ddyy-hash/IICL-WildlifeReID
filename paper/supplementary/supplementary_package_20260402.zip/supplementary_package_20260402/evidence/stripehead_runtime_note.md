# Stripe-Head Runtime Proxy

Anonymous server-GPU quick benchmark with batch size `1` and input size `256 x 384`.

| Pipeline | Params (M) | Latency (ms) | FPS | Resident GPU Mem (MB) | Peak GPU Mem (MB) |
|---|---:|---:|---:|---:|---:|
| Stripe-head baseline | 4.10 | 6.05 | 165.29 | 25.06 | 93.05 |
| Full RIIC-ReID | 4.57 | 27.10 | 36.90 | 38.55 | 288.99 |

## Interpretation

- Parameter count increases by `+0.47M` from the stripe-head baseline to Full RIIC-ReID.
- This is a server-side proxy benchmark and is included only as supplementary efficiency context.
