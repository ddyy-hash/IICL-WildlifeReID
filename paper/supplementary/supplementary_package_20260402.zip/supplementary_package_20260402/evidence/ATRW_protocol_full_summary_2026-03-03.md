# ATRW Protocol Package Note

The original workspace contained a longer literature audit for ATRW protocol tracing. In the anonymous supplementary package, that audit has been reduced to the compact reviewer-facing files below:

- `evidence/atrw_protocol_comparison.md`
- `evidence/atrw_protocol_comparison.csv`

These two files serve as the package-local source of record for ATRW protocol clarification.
