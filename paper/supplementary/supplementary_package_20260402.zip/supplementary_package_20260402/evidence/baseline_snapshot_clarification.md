# Baseline Snapshot Clarification

The conceptual baseline family described in the paper is a no-illumination ReID control. For reproducibility inside this anonymous package, the literal source of record is the exact snapshot below:

- `config/experiments/main_atrw/plain_baseline_exact.yaml`

This packaged control keeps the paper-facing backbone, input resolution, and total epoch budget fixed while simplifying the no-illumination branch into a pure ReID control. In this exact snapshot:

- the illumination module is disabled;
- feature fusion and branch-attention fusion are disabled;
- the nuisance head is disabled;
- the ReID head is `plain_global`;
- the local extractor uses one part in the exact snapshot;
- PK sampling is disabled in the exact snapshot;
- only the base cross-entropy term remains active among the metric-learning losses.

For auditing the paper-facing numbers, this exact YAML snapshot should be treated as the authoritative baseline definition inside the supplementary package.
