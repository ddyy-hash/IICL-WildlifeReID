# ATRW Five-Checkpoint Stability Summary

This file summarizes a compact checkpoint-stability diagnostic over five saved checkpoints for each paper-facing ATRW variant. It supports the paper's reliability claims and is not intended to replace the final headline checkpoint table.

| Variant | Single-camera mAP | Cross-camera mAP | mmAP | Single-camera Rank-1 | Cross-camera Rank-1 |
|---|---:|---:|---:|---:|---:|
| Matched ReID baseline | 72.44 +/- 0.10 | 40.73 +/- 0.07 | 56.59 +/- 0.08 | 90.04 +/- 0.16 | 78.55 +/- 0.10 |
| Naive illumination | 70.88 +/- 0.49 | 39.12 +/- 0.36 | 55.00 +/- 0.36 | 89.39 +/- 0.89 | 73.15 +/- 0.36 |
| Illumination only | 73.75 +/- 0.65 | 40.66 +/- 0.46 | 57.21 +/- 0.48 | 89.64 +/- 0.77 | 75.96 +/- 0.36 |
| Full RIIC-ReID | 73.98 +/- 0.42 | 41.55 +/- 0.39 | 57.76 +/- 0.36 | 88.50 +/- 0.89 | 76.22 +/- 0.45 |

## Key Takeaways

- The naive illumination variant is both weaker and more volatile than the matched baseline.
- The full model remains the strongest variant in cross-camera mAP and mmAP under this checkpoint-level diagnostic.
- The full model's variability is modest and lower than that of the illumination-only variant in mmAP.
