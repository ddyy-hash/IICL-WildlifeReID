# Geometry Case Summary

This file records the compact geometry-oriented case used in the supplementary note on teacher-guided manifold supervision.

- Query: `query/21/001132.jpg`
- Query label: `21`
- Number of teacher positives in the local gallery: `13`
- Teacher radius (L2): `0.7443`
- Raw query distance to teacher center: `0.6481`
- Perceptual-enhanced query distance to teacher center: `0.7051`
- RIIC query distance to teacher center: `0.6446`
- Nearest negative distance to teacher center: `0.7750`
- Net geometry gain (`perceptual - RIIC` distance to center): `0.0605`

## Interpretation

- The perceptual alternative drifts farther from the teacher-positive neighborhood than both the raw query and the RIIC-corrected query.
- RIIC stays within a tighter same-identity neighborhood while preserving a margin to the nearest negative cluster.
