# ATRW Protocol Comparison

This note explains which ATRW settings are comparable with the main paper and which are not.

## 1. Reviewer-Facing Conclusion

The paper uses an official-like ATRW open-set protocol:

- train split: 1887 images / 107 identities
- test split: 1762 images / 75 identities
- headline metrics: single-camera mAP, cross-camera mAP, and their mean (mmAP)

This protocol family matches the paper's main ATRW table. Package-local summary data is also provided in `evidence/atrw_protocol_comparison.csv`.

## 2. Protocol Classes

| Protocol class | Representative papers | Query/gallery logic | Comparable to the paper's main ATRW table? |
|---|---|---|---|
| `official_like` | ATRW benchmark, PPGNet, PGCFL, Robust Animal Re-Identification | Each test image is queried against the official test-gallery logic, with single-camera and cross-camera reporting | Yes |
| `modified` | Serial Multi-Scale, IndivAID, WildlifeDatasets toolkit examples | Uses custom fixed-query/gallery partitions, reduced subsets, or closed-set toolkit splits | No |

## 3. Why the Distinction Matters

- The paper's main ATRW claim is about cross-camera illumination shift under the official-like open-set setting.
- Results obtained under custom fixed-query/gallery or closed-set splits are still useful diagnostics, but they should not be mixed into the same headline ATRW comparison table.
- This is why the package keeps the official-like ATRW evidence separate from the cross-species fixed-query/gallery evidence.

## 4. Package-Local Entry Points

- `code/tools/prepare_atrw_official.py`
- `code/tools/create_openset_split.py`
- `code/tools/eval_atrw_openset.py`
- `code/tools/eval_atrw_closedset.py`
- `code/tools/selection_protocols.py`

## 5. Source of Record Inside This Package

For reviewer use, the package-local source of record is:

- `evidence/atrw_protocol_comparison.csv`

The longer literature audit that existed in the full workspace was intentionally reduced so that the anonymous supplementary package remains compact and self-contained.
