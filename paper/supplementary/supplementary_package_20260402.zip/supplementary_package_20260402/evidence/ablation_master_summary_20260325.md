# Ablation Master Summary

Prepared for the anonymous supplementary package on 2026-04-02.

This summary retains only the reviewer-facing results that are both cited by the current anonymous manuscript and traceable within this package. Older exploratory runs are omitted to avoid protocol mixing.

## 1. ATRW Main Ablation

| Variant | mAP single | mAP cross | mmAP | Delta vs plain |
|---|---:|---:|---:|---:|
| Plain ReID baseline | 72.52 | 40.87 | 56.69 | 0.00 |
| Naive illumination | 71.65 | 39.60 | 55.62 | -1.07 |
| Illumination only | 74.30 | 41.43 | 57.86 | +1.17 |
| Full RIIC-ReID | 74.43 | 41.80 | 58.11 | +1.42 |

Local source: `evidence/atrw_main_ablation_final.csv`

## 2. ATRW Backbone Robustness

| Backbone | Baseline mmAP | Full mmAP | Delta mmAP | Baseline cross mAP | Full cross mAP | Delta cross mAP |
|---|---:|---:|---:|---:|---:|---:|
| OSNet-AIN X1.0 | 56.69 | 58.11 | +1.42 | 40.87 | 41.80 | +0.93 |
| OSNet X1.0 | 59.06 | 60.50 | +1.44 | 43.35 | 44.75 | +1.40 |
| ResNet-50 | 56.61 | 57.62 | +1.01 | 42.92 | 43.97 | +1.05 |

Local source: `evidence/atrw_backbone_robustness.csv`

## 3. Cross-Species Fixed-Query/Gallery Evidence

| Dataset | Variant | Rank-1 | mAP | Delta vs baseline |
|---|---|---:|---:|---:|
| GZGC Zebra | White-box baseline | 71.70 | 70.32 | 0.00 |
| GZGC Zebra | Generic illumination | 74.48 | 72.71 | +2.39 |
| GZGC Zebra | Full RIIC-ReID | 75.92 | 74.22 | +3.90 |
| StripeSpotter | White-box baseline | 93.00 | 91.55 | 0.00 |
| StripeSpotter | Generic illumination | 92.00 | 91.29 | -0.26 |
| StripeSpotter | Full RIIC-ReID | 94.00 | 93.89 | +2.34 |

Local source: `evidence/cross_species_fixedqg_results.csv`

## 4. Generic Perceptual-Enhancement Baselines

| Dataset | Method | Rank-1 | mAP | Single mAP | Cross mAP | mmAP |
|---|---|---:|---:|---:|---:|---:|
| ATRW | Zero-DCE++ | - | - | 73.14 | 42.36 | 57.75 |
| ATRW | RetinexNet | - | - | 71.70 | 41.64 | 56.67 |
| GZGC Zebra | Zero-DCE++ | 68.01 | 67.31 | - | - | - |
| GZGC Zebra | RetinexNet | 68.64 | 68.51 | - | - | - |

Local source: `evidence/perceptual_baseline_results.csv`

## 5. Recommended Reviewer Path

If you want the minimum evidence trail needed to audit the paper, the most useful files are:

1. `evidence/claim_to_artifact_map.md`
2. `evidence/atrw_main_ablation_final.csv`
3. `evidence/atrw_backbone_robustness.csv`
4. `evidence/cross_species_fixedqg_results.csv`
5. `evidence/perceptual_baseline_results.csv`
6. `evidence/atrw_protocol_comparison.md`
