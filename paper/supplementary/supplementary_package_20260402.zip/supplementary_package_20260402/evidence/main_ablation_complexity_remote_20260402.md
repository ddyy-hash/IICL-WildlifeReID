# Main Ablation Complexity (Anonymized Remote THOP Run)

Execution context: anonymized remote Linux GPU workspace

Input size: `1 x 3 x 256 x 384`  
Profiler: `thop`

| Variant | Params (M) | MACs (G) | Config snapshot |
|---|---:|---:|---|
| Plain baseline | 1.747 | 10.666 | `config/experiments/main_atrw/plain_baseline_exact.yaml` |
| Naive illumination | 3.614 | 20.100 | `config/experiments/main_atrw/naive_illumination_exact.yaml` |
| Illumination only | 3.928 | 32.453 | `config/experiments/main_atrw/illumination_only_exact.yaml` |
| Full RIIC-ReID | 3.773 | 43.111 | `config/experiments/main_atrw/full_model_exact.yaml` |

## Notes

- These values are static complexity proxies computed from the exact paper-facing ATRW variant snapshots.
- The measured runtime and memory table in `atrw_efficiency_batch1_riic.md` is the primary runtime evidence.
- The THOP estimate should be interpreted as complementary complexity evidence rather than combined directly with the measured runtime table.
