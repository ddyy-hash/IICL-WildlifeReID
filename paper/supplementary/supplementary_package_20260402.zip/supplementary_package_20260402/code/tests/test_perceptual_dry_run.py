import sys
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

import tools.run_perceptual_baseline_ablation as perceptual_module


def test_build_jobs_allows_dry_run_without_preprocessed_gzgc_dirs(monkeypatch, tmp_path) -> None:
    output_root = tmp_path / "generated"
    enhanced_root = tmp_path / "enhanced"

    monkeypatch.setattr(perceptual_module, "ENHANCED_DATA_ROOT", enhanced_root)
    monkeypatch.setattr(
        perceptual_module,
        "load_config",
        lambda _path: {"model": {}, "training": {}, "evaluation": {"protocol": "query_gallery"}},
    )
    monkeypatch.setattr(perceptual_module, "_materialize_joint_phase_defaults", lambda _cfg: None)
    monkeypatch.setattr(
        perceptual_module,
        "_dataset_runtime_from_config",
        lambda _cfg, _dataset_key: {
            "train_data_dir": "data/processed/gzgc_zebra/train",
            "query_dir": "data/processed/gzgc_zebra/query",
            "gallery_dir": "data/processed/gzgc_zebra/gallery",
            "protocol": "query_gallery",
        },
    )
    monkeypatch.setattr(
        perceptual_module,
        "derive_plain_baseline_config",
        lambda _cfg, backbone_override=None, total_epochs=None, baseline_head=None: {
            "model": {},
            "training": {},
            "evaluation": {},
        },
    )
    monkeypatch.setattr(perceptual_module, "_sum_effective_phase_epochs", lambda _cfg: 12)
    monkeypatch.setattr(perceptual_module, "_force_bf16_amp", lambda _cfg: None)
    monkeypatch.setattr(perceptual_module, "_normalize_training_protocol", lambda _cfg, _runtime: None)
    monkeypatch.setattr(
        perceptual_module,
        "_apply_runtime_dirs",
        lambda cfg, runtime: cfg.setdefault("runtime", {}).update(runtime),
    )
    monkeypatch.setattr(
        perceptual_module,
        "_stamp_paper_protocol_metadata",
        lambda *_args, **_kwargs: None,
    )
    monkeypatch.setattr(perceptual_module, "_configure_perceptual_checkpointing", lambda _cfg: None)

    jobs = perceptual_module.build_jobs(
        ["gzgc_zebra"],
        ["zerodcepp"],
        output_root=output_root,
        device="cpu",
        atrw_data_root="unused",
        atrw_eval_script_dir="unused",
        skip_preprocess=True,
        allow_missing_preprocessed=True,
    )

    assert len(jobs) == 1
    job = jobs[0]
    expected_root = enhanced_root / "gzgc_zebra" / "zerodcepp"
    assert job.train_data_dir == (expected_root / "train").as_posix()
    assert job.query_dir == (expected_root / "query").as_posix()
    assert job.gallery_dir == (expected_root / "gallery").as_posix()
    assert job.config["perceptual_baseline"]["selection_query_dir"] == (
        expected_root / "selection_query"
    ).as_posix()
    assert job.config["perceptual_baseline"]["selection_gallery_dir"] == (
        expected_root / "selection_gallery"
    ).as_posix()
