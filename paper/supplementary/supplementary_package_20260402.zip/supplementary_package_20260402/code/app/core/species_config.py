#!/usr/bin/env python3
"""Species-type configuration helpers for dataset-specific IPAID defaults."""

from __future__ import annotations

SPECIES_TYPE_MAP = {
    # Stripe-pattern species: standard illumination correction behavior.
    "atrw": "stripe",
    "gzgc_zebra": "stripe",
    "stripespotter": "stripe",
    "nyala": "stripe",
    # Spot-pattern species: weaker correction and stronger color protection.
    "gzgc_giraffe": "spot",
    "leopard": "spot",
    # Plain-color species: moderate correction without color illumination.
    "ipanda50": "plain",
    "czechlynx": "plain",
}


def get_species_type(dataset_name: str) -> str:
    """Infer the species-pattern type from a dataset name."""
    dataset_key = dataset_name.lower().replace("-", "_").replace(" ", "_")
    for key, species_type in SPECIES_TYPE_MAP.items():
        if key in dataset_key or dataset_key in key:
            return species_type

    print(f"[WARN] Unknown dataset '{dataset_name}', defaulting to 'stripe'.")
    return "stripe"


def get_ipaid_params(dataset_name: str) -> dict:
    """Return lightweight IPAID defaults adapted to the target species pattern."""
    species_type = get_species_type(dataset_name)
    params = {
        "base_channels": 32,
        "num_scales": 3,
        "refine_iterations": 2,
        "use_sensitivity": True,
        "use_refinement": True,
        "use_feature_guided": True,
        "species_type": species_type,
    }

    if species_type == "spot":
        # Spot-pattern datasets are more sensitive to color drift.
        params["use_color_illumination"] = True
        print(
            f"[Config] Dataset '{dataset_name}' is spot-type: "
            "color illumination will be internally disabled."
        )
    elif species_type == "stripe":
        params["use_color_illumination"] = True
    else:
        params["use_color_illumination"] = False

    return params


if __name__ == "__main__":
    print("Species-Type Configuration")
    print("=" * 60)

    for dataset_name in SPECIES_TYPE_MAP:
        species_type = get_species_type(dataset_name)
        params = get_ipaid_params(dataset_name)
        print(f"\n{dataset_name}:")
        print(f"  Species type:       {species_type}")
        print(f"  Color illumination: {params['use_color_illumination']}")
        print(f"  Feature guided:     {params['use_feature_guided']}")
