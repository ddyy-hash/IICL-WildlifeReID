"""Core package lazy exports.

This module keeps `app.core` lightweight by delaying heavy imports until they
are actually requested by callers.
"""

from __future__ import annotations

__all__ = [
    "DogReIDSystem",
    "yolo_seg",
    "start_frame_stream_detection",
    "stop_frame_stream_mode",
]


def __getattr__(name: str):
    if name == "DogReIDSystem":
        from .dog_reid_system import DogReIDSystem

        return DogReIDSystem
    if name == "yolo_seg":
        from .yolo_segment import yolo_seg

        return yolo_seg
    if name == "start_frame_stream_detection":
        from .camera_system import start_frame_stream_detection

        return start_frame_stream_detection
    if name == "stop_frame_stream_mode":
        from .camera_system import stop_frame_stream_mode

        return stop_frame_stream_mode
    raise AttributeError(name)
