#!/bin/bash
# ATRW V2 training helper for the enhanced illumination-correction pipeline.
# The script trains the model, exports qualitative visualizations, and then
# generates the full analysis bundle used during internal inspection.

set -e

echo "=========================================="
echo "ATRW V2 Enhanced Training Pipeline"
echo "=========================================="

# Configuration
CONFIG="../config/experiments/main_atrw/full_model_exact.yaml"
OUTPUT_DIR="../artifacts/generated/atrw_v2_enhanced"
DEVICE="cuda"

# 1. Train the model
echo ""
echo "[1/3] Starting training..."
python tools/train_joint_reid.py \
  --config ${CONFIG} \
  --device ${DEVICE}

# 2. Generate visualization comparisons
echo ""
echo "[2/3] Rendering qualitative comparisons..."
python tools/visualize_color_correction_v2.py \
  --checkpoint ${OUTPUT_DIR}/joint_best.pth \
  --input_dir data/processed/atrw/query \
  --output_dir ${OUTPUT_DIR}/visualization \
  --num_examples 8 \
  --device ${DEVICE}

# 3. Generate the full analysis report
echo ""
echo "[3/3] Building the analysis bundle..."
python tools/visualize_joint_analysis.py \
  --checkpoint ${OUTPUT_DIR}/joint_best.pth \
  --query_dir data/processed/atrw/query \
  --gallery_dir data/processed/atrw/gallery \
  --output_dir ${OUTPUT_DIR}/analysis \
  --device ${DEVICE}

echo ""
echo "=========================================="
echo "Training complete."
echo "=========================================="
echo "Checkpoint:     ${OUTPUT_DIR}/joint_best.pth"
echo "Visualizations: ${OUTPUT_DIR}/visualization/"
echo "Analysis:       ${OUTPUT_DIR}/analysis/"
echo ""
echo "Reference comparison:"
echo "  V1: checkpoints/atrw_new_version_1/analysis_joint_best/"
echo "  V2: ${OUTPUT_DIR}/analysis/"
